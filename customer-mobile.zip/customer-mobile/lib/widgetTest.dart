import 'package:flutter/material.dart';
import 'package:rivver/customWidgets/appBars/appBar.dart';
import 'package:rivver/views/home/homeScreen.dart';

class TestView extends StatefulWidget {
  const TestView({Key? key}) : super(key: key);

  @override
  _TestViewState createState() => _TestViewState();
}

class _TestViewState extends State<TestView> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBodyBehindAppBar: true,
        body: NestedScrollView(headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return <Widget>[CustomAppBar(innerBoxIsScrolled: innerBoxIsScrolled)]; }, body:PageView(
          children: [
            SingleChildScrollView(child: HomeScreen(gender:'male')),
          ],
        ),

          
        ),
      ),
    );
  }
}
