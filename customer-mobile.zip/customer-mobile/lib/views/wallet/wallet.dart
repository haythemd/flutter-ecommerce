import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:rivver/customWidgets/walletHistory.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';

class WalletPage extends StatefulWidget {
  const WalletPage({Key? key}) : super(key: key);

  @override
  _WalletPageState createState() => _WalletPageState();
}

class _WalletPageState extends State<WalletPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('WALLET'),
        backgroundColor: onyx,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: InkWell(
                onTap: () {
                  print('Navigate to FAQ screen');
                },
                child: Container(
                  padding: EdgeInsets.only(top: 2),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(8),
                          bottomRight: Radius.circular(8)),
                      border: Border(
                        left: BorderSide(color: onyx, width: 1),
                        bottom: BorderSide(color: onyx, width: 1),
                        right: BorderSide(color: onyx, width: 1),
                        top: BorderSide(color: onyx, width: 1),
                      )),
                  height: 30,
                  width: 120,
                  child: Text(
                    'How it Works',
                    style: nexaTextBlack,
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 18.0, bottom: 28),
              child: Text(
                'Your Wallet Credit',
                style: nexaBoldBlack,
              ),
            ),
            SvgPicture.asset(
              'assets/icons/wallet.svg',
              height: 70,
            ),
            Text('\n1.39 EGP',
                style: TextStyle(
                    fontFamily: 'Nexa',
                    color: Color(0xFF11CAB2),
                    fontWeight: FontWeight.w700)),
            Text(
              'Applied in your next purchase',
              style: segoeGreySmall,
            ),
            Padding(
              padding: const EdgeInsets.only(top: 18.0),
              child: MaterialButton(
                onPressed: () {},
                child: Text(
                  'Continue Shopping',
                  style: segoeWhiteSmall,
                ),
                minWidth: 300,
                height: 45,
                color: onyx,
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              color: Color(0xFFCCCCCC),
              child: SizedBox.fromSize(
                size: Size.fromHeight(60),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Spacer(),
                    Container(
                        width: 150,
                        height: 40,
                        child: TextFormField(
                          initialValue: 'Gift Card',
                          style: segoeBlack18,
                        )),Spacer(flex: 7,),
                    MaterialButton(
                      onPressed: () {},
                      child: Text('APPLY',style: TextStyle(fontFamily: 'SegoeUI',color: Colors.white,fontSize: 22),),
                      color: Color(0xFF11CAB2),
                      minWidth: 80,
                      height: 40,
                    ),Spacer()
                  ],
                ),
              ),
            ),
            SizedBox(height: 20,),
            Row(
              children: [
                Text(
                  '  Wallet History',
                  style: nexaBoldBlack,
                ),
              ],
            ),
            Divider(thickness: 1.8,),
            Row(
              children: [
                Spacer(flex: 4,),
                Text(
                  'ADDED',
                  style: segoeBlack18,
                ),
                Spacer(),
                Text(
                  'USED',
                  style: segoeBlack18,
                ),
                Spacer(),
              ],
            ),
            Divider(thickness: 1.8,),
            WalletHistory(),
            Divider(thickness: 1.8,),
            WalletHistory(),
            Divider(thickness: 1.8,),
            WalletHistory(),
          ],
        ),
      ),
    );
  }
}
