import 'package:flutter/material.dart';
import 'package:rivver/constants.dart';
import 'package:rivver/customWidgets/bottomNavBars/bottomNavBar.dart';
import 'package:rivver/views/categories/subCategories.dart';

class CategoriesPage extends StatefulWidget {
  const CategoriesPage({Key? key}) : super(key: key);

  @override
  _CategoriesPageState createState() => _CategoriesPageState();
}

class _CategoriesPageState extends State<CategoriesPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.black,
      body: Container(
        margin: kPaddingAll,
        child: ListView.builder(
            itemCount: 6,
            itemBuilder: (context, index) {
              return Container(
                  height: 180,
                  child: Hero(
                    tag: index,
                    child: GestureDetector(
                        child: Image.asset(
                      categories[index],
                      fit: BoxFit.cover,
                    ),
                      onTap: (){Navigator.of(context).push(PageRouteBuilder(transitionDuration: Duration(milliseconds: 1500),pageBuilder: (context,_,__)=>SubCategoryPage(index: index, url: categories[index])));},
                    
                    ),
                  ));
            }),
      ),
      bottomNavigationBar: MainNavBar(),
    );
  }
}
