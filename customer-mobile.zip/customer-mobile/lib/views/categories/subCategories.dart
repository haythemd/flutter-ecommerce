
import 'package:flutter/material.dart';
import 'package:rivver/customWidgets/appBars/appBar.dart';
import 'package:rivver/customWidgets/bottomNavBars/bottomNavBar.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';

class SubCategoryPage extends StatefulWidget {
  const SubCategoryPage({Key? key,required this.index,required this.url}) : super(key: key);
final String url;
final int index;



  @override
  _SubCategoryPageState createState() => _SubCategoryPageState();
}

class _SubCategoryPageState extends State<SubCategoryPage> {
  double opacity = 0;
  @override
  void initState() {

    opacity =1;

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,backgroundColor: onyx,
    body: NestedScrollView(headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) { return [CustomAppBar(innerBoxIsScrolled: innerBoxIsScrolled)]; },
      body: Stack(
        children: [
          SizedBox.expand(child: Hero(tag: this.widget.index, child: Image.asset(this.widget.url,fit: BoxFit.cover,)),
          ),


        Container(color: Colors.black87,
          child: AnimatedOpacity(

            child: Column(
              children: [Padding(padding: EdgeInsets.symmetric(vertical: 50),
                child: Text('Explore Further',style: vladivostokBig,),
              ),
                Row(mainAxisAlignment: MainAxisAlignment.spaceAround,children: [
                  Column(mainAxisAlignment: MainAxisAlignment.center,crossAxisAlignment: CrossAxisAlignment.start,children: [
                    TextButton(child:Text('Jeans',style: segoeWhiteBig,),onPressed: (){},),
                    TextButton(child:Text('Skirts',style: segoeWhiteBig,),onPressed: (){},),
                    TextButton(child:Text('T-shirts',style: segoeWhiteBig,),onPressed: (){},),
                    TextButton(child:Text('Sandals',style: segoeWhiteBig,),onPressed: (){},),
                    TextButton(child:Text('Sneakers',style: segoeWhiteBig,),onPressed: (){},),
                  ],),
                  Column(mainAxisAlignment: MainAxisAlignment.center,crossAxisAlignment: CrossAxisAlignment.start,children: [
                    TextButton(child:Text('Outfits',style: segoeWhiteBig,),onPressed: (){},),
                    TextButton(child:Text('OuterWear',style: segoeWhiteBig,),onPressed: (){},),
                    TextButton(child:Text('Indoor',style: segoeWhiteBig,),onPressed: (){},),
                    TextButton(child:Text('Outdoor',style: segoeWhiteBig,),onPressed: (){},),
                    TextButton(child:Text('Lorem',style: segoeWhiteBig,),onPressed: (){},),
                  ],),
                ],),
              ],
            ),
            duration: Duration(milliseconds: 5800), opacity: opacity,
          ),
        )

        ],
      ),

    ),
      bottomNavigationBar: MainNavBar(),
    );
  }
}
