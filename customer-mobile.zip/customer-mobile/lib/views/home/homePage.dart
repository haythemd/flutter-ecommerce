import 'package:flutter/material.dart';
import 'package:rivver/customWidgets/appBars/appBar.dart';
import 'package:rivver/customWidgets/bottomNavBars/bottomNavBar.dart';
import 'homeScreen.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool searching = false;
  late FocusNode searchFocusNode;
  ScrollController scrollController = ScrollController();
  PageController pageController = PageController();
  bool isUp = true;
  @override
  void initState() {
    WidgetsBinding.instance!.addPostFrameCallback((_) {
      searchFocusNode = FocusNode();
    });

    super.initState();
  }

  @override
  void dispose() {
    searchFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      extendBodyBehindAppBar: true,
      body: NestedScrollView(
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return <Widget>[
            CustomAppBar(innerBoxIsScrolled: innerBoxIsScrolled)
          ];
        },
        body: Container(
          child: PageView(
            children: [
              HomeScreen(gender: 'male'),
            ],
          ),
        ),
      ),
      bottomNavigationBar: MainNavBar(),
    );
  }
}
