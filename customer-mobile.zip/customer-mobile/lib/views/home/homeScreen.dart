import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/material.dart';
import 'package:rivver/constants.dart';
import 'package:rivver/customWidgets/home/bannersSlider.dart';
import 'package:rivver/customWidgets/home/brandSlider.dart';
import 'package:rivver/customWidgets/home/constantHomeWidgets.dart';
import 'package:rivver/customWidgets/home/productWidget.dart';
import 'package:rivver/customWidgets/home/subCategoriesSlider.dart';
import 'package:rivver/style/fonts.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key, required this.gender}) : super(key: key);
  final String gender;

// Taking the gender variable from the Previous screen to see which Category is to be selelcte
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  final foo = false;

  late TabController tabController = TabController(length: 8, vsync: this);
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRect(clipBehavior: Clip.hardEdge,
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            BannerSlider(),
            const Heading(text: 'Top Selling Brands',),
            BrandSlider(),
           const  Heading(text: 'Trending',),
            Divider(
              thickness: 1.5,
            ),
            Padding(
              padding: kPaddingAll,
              child: SizedBox.fromSize(
                size: Size.fromHeight(320),
                child: Container(
                  child: Swiper(
                      itemCount: 6,
                      itemBuilder: (BuildContext context, int) {
                        return Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Expanded(
                              child: GestureDetector(
                                child: ProductWidget(tag: int.toDouble(),),
                                onTap: () { },
                                onDoubleTap: () {
                                  //Implement Add to Favorites
                                },
                              ),
                            ),
                            Expanded(
                              child: ProductWidget(
                                promoUrl: 'haha',tag: int.toDouble()+0.5,

                              ),
                            )
                          ],
                        );
                      }),
                ),
              ),
            ),
            Padding(
              padding: kPaddingAll,
              child: Align(
                child: Text(
                  '  On Sale!',
                  style: segoeBlackBold,
                ),
                alignment: Alignment.topLeft,
              ),
            ),
            Divider(
              thickness: 1.5,
            ),
            Padding(
              padding: kPaddingAll,
              child: SizedBox.fromSize(
                size: Size.fromHeight(300),
                child: Container(
                  child: Swiper(
                      itemCount: 6,
                      itemBuilder: (BuildContext context, int) {
                        return Row(
                          children: [
                            Expanded(child: ProductWidget(tag: int.toDouble()+0.2,)),
                            Expanded(
                              child: ProductWidget(tag: int.toDouble()+0.3,),
                            )
                          ],
                        );
                      }),
                ),
              ),
            ),
            Container(
              height: 5000,
            )
          ],
        ),
      ),
    );
  }
}
