import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:rivver/customWidgets/appBars/appBar.dart';
import 'package:rivver/customWidgets/bottomNavBars/bottomNavBar.dart';
import 'package:rivver/customWidgets/home/productWidget.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';

class Favorites extends StatefulWidget {
  const Favorites({Key? key}) : super(key: key);

  @override
  _FavoritesState createState() => _FavoritesState();
}

class _FavoritesState extends State<Favorites> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('WISHLIST'),
        centerTitle: true,
        leadingWidth: 30,
        backgroundColor: onyx,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: Icon(
            Icons.arrow_back_ios_new,
            size: 28,
          ),
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(18.0),
            child: Stack(
              alignment: Alignment.center,
              children: [
                CircleAvatar(
                  backgroundColor: Color(0xFFEEEEEE),
                  minRadius: 120,
                ),
                Icon(
                  Icons.favorite,
                  size: 150,
                ),
                Positioned(
                  top: 10,
                  right: 70,
                  child: Icon(
                    Icons.auto_awesome_outlined,
                    size: 50,
                  ),
                ),
              ],
            ),
          ),
          Text(
            "Your Wishlist is empty. Start filling it up!",
            style: segoeBlackBold,
          ),
          Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: MaterialButton(
                onPressed: () {
                  Navigator.of(context).pushReplacementNamed('home');
                },
                height: 40,
                color: Colors.black,
                minWidth: 300,
                child: Text(
                  'Start Shopping',
                  style: segoeWhiteSmall,
                ),
              )),
        ],
      ),
    );
  }
}

class FavoritesTrue extends StatefulWidget {
  const FavoritesTrue({Key? key}) : super(key: key);

  @override
  _FavoritesTrueState createState() => _FavoritesTrueState();
}

class _FavoritesTrueState extends State<FavoritesTrue> {
  String dropdownValue='S';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NestedScrollView(
          headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
            return [
              CustomAppBar(innerBoxIsScrolled: innerBoxIsScrolled),
              SliverList(
                  delegate: SliverChildBuilderDelegate((BuildContext context, int) {
                return Stack(
                  key: UniqueKey(),
                  children: [
                    Container(
                      margin: EdgeInsets.symmetric(vertical: 5, horizontal: 15),
                      color: Colors.white,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            children: [
                              Image.asset('assets/images/t-shirt2.png'),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: InkWell(
                                  onTap: (){ print('Hello');},
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.file_upload_outlined,
                                      ),
                                      Text(
                                        'Share',
                                        style: segoeBlackSmall,
                                      )
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 14.0),
                            child: Column(
                              children: [
                                Text('\nAdidas',style: segoeBlackSmall,),
                                Text('Bucket hat',style: gothicGreySmall,),
                                Text('EGP 116.95',style: segoeBlackSmall,),
                                Container(decoration: BoxDecoration(border: Border.all(width: 0.2)),
                                  width: 150,height: 30,margin: EdgeInsets.only(top: 10,bottom: 23),
                                  padding: EdgeInsets.only(left: 10),
                                  child: DropdownButton<String>(
                                    value: dropdownValue,
                                    icon: const Icon(Icons.arrow_downward),
                                    iconSize: 24,
                                    elevation: 16,
                                    isDense: true,isExpanded: true,
                                    style:  TextStyle(color: onyx),


                                     onChanged: (String? newValue) {
                                      setState(() {
                                        dropdownValue = newValue!;
                                      });
                                    },
                                    items: <String>['S', 'M', 'L', 'XL']
                                        .map<DropdownMenuItem<String>>((String value) {
                                      return DropdownMenuItem<String>(
                                        value: value,
                                        child: Text(value,style: segoeBlackSmall,),
                                      );
                                    }).toList(),
                                  ),
                                ),

                                MaterialButton(
                                  onPressed: () {
                                  },
                                  height: 40,
                                  color: Colors.black,
                                  minWidth: 150,

                                  child: Text(
                                    'Add To Bag',
                                    style: segoeWhiteSmall,
                                  ),
                                )
                              ],
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                          )
                        ],
                      ),
                    ),
                    Positioned(child:IconButton(onPressed: (){


                    },icon: Icon(
                      Icons.close_outlined,size: 24,
                    ),),top: 5,right: 10,)
                  ],
                );
              },childCount: 8))
            ];
          },
          body: Container(decoration: BoxDecoration(color: Colors.white),
            child: Stack(
              children: [
                Positioned(child: Container(child: Text("Trending Now !",style: GoogleFonts.bebasNeue(fontSize: 56,color: onyx,fontWeight: FontWeight.w700),textAlign: TextAlign.center,)),top: 100,left: 10,right: 10,),
                Container(height: 300,margin: EdgeInsets.only(top: 250,left: 20,right: 20,bottom: 10),
                  child: ListView.builder(itemBuilder: (BuildContext context, int){

                        return Center(child: Container(height: 300,child: ProductWidget(tag: int.toDouble())));
                      },scrollDirection: Axis.horizontal,reverse: false,itemCount: 10,),
                ),
              ],
            ),
          ),),
      bottomNavigationBar: MainNavBar(),
      backgroundColor: Colors.white,
    );
  }
}
