import 'package:flutter/material.dart';
import 'package:rivver/customWidgets/appBars/normalAppBar.dart';
import 'package:rivver/customWidgets/bottomNavBars/bottomNavBar.dart';
import 'package:rivver/style/themes.dart';
import 'components/body.dart';

class CartScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: mainAppBar(context),
      body: Body(),
      bottomNavigationBar: MainNavBar(),
    );
  }

}