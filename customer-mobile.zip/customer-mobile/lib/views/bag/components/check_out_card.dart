import 'package:flutter/material.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';
import '../../../size_config.dart';

class CheckoutCard extends StatelessWidget {
  const CheckoutCard({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(


      ),
      // height: 174,

      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Divider(thickness: 1.8,),
            Row( mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [

                Text("   Total: ",
                    style: nexaBlack,
                ),
                      Text("EGP 337.15   ",
                        style: TextStyle(fontSize: 20, color: Colors.black,fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),



            Divider(thickness: 1.8,),
            SizedBox(height: getProportionateScreenHeight(20)),

            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(10),

                  decoration: BoxDecoration(
                    color: Color(0xFFF5F6F9),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    Icons.receipt_outlined,
                  ),
                ),

                Container(child: Text("Add voucher code",style: segoeBlack18,)),
                const SizedBox(width: 5),
                Icon(
                  Icons.arrow_forward_ios,
                  size: 22,
                  color: Colors.black,
                ),SizedBox(width: 15,),
                Flexible(
                  child: MaterialButton(
                    color: onyx,
                    padding: EdgeInsets.symmetric(vertical: 10, horizontal:25),
                    child: Text("Check Out", style: segoeWhiteSmall),
                    onPressed: () {},
                  ),
                ),
              ],
            ),


          ],
        ),
      ),
    );
  }
}