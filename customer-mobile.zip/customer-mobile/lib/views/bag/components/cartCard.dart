import 'package:awesome_dropdown/awesome_dropdown.dart';
import 'package:flutter/material.dart';
import 'package:rivver/models/cart.dart';
import 'package:rivver/style/fonts.dart';
import '../../../size_config.dart';

class CartCard extends StatefulWidget {
  const CartCard({
    Key? key,
    required this.cart,
  }) : super(key: key);

  final Cart cart;

  @override
  State<CartCard> createState() => _CartCardState();
}

class _CartCardState extends State<CartCard> {
  final bool _isPanDown= false;

  final List<String> _list = ['1','2','3','4','5'];



  @override
  Widget build(BuildContext context) {
    return Container(decoration: BoxDecoration(
      color: Color(0xFFF5F6F9),
      borderRadius: BorderRadius.circular(15),
    ),
      child: Row(
        children: [
          SizedBox(
            width: 88,
            child: AspectRatio(
              aspectRatio: 0.88,
              child: Container(
                padding: EdgeInsets.all(getProportionateScreenWidth(10)),
                decoration: BoxDecoration(
                  color: Color(0xFFF5F6F9),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Image.asset(this.widget.cart.product.images[0]),
              ),
            ),
          ),
          SizedBox(width: 20),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                this.widget.cart.product.title,
                style: TextStyle(color: Colors.black, fontSize: 16),
                maxLines: 2,
              ),
              SizedBox(height: 10),

                Text("\EGP${this.widget.cart.product.price}",
                  style: TextStyle(
                      fontWeight: FontWeight.w200, color: Colors.grey[600]),

                ),

            ],
          ),



        ],
      ),
    );
  }
}