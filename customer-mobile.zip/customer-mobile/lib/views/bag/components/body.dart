import 'package:flutter/material.dart';
import 'package:rivver/models/cart.dart';


import '../../../size_config.dart';
import 'cartCard.dart';
import 'check_out_card.dart';

class Body extends StatefulWidget {
  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> {
  @override
  void initState() {
    super.initState();
  }
  String? _selectedItem='1';
  bool _isDropDownOpened = false;
  bool _isBackPressedOrTouchedOutSide= true;
  @override
  Widget build(BuildContext context) {
    return Container(color: Color(0xFFEEEEEE),
      child: Padding(
        padding:
        EdgeInsets.symmetric(horizontal: getProportionateScreenWidth(20)),
        child: Column(
          children: [
            Flexible(flex: 8,
              child: Container(
                height: SizeConfig.screenHeight*0.7,
                child: ListView.builder(
                  itemCount: demoCarts.length,
                  itemBuilder: (context, index) => Padding(
                    padding: EdgeInsets.symmetric(vertical: 10),
                    child: Dismissible(
                      key: Key(demoCarts[index].product.id.toString()),
                      direction: DismissDirection.endToStart,
                      onDismissed: (direction) {
                        setState(() {
                          demoCarts.removeAt(index);
                        });
                      },
                      background: Container(
                        padding: EdgeInsets.symmetric(horizontal: 20),
                        decoration: BoxDecoration(
                          color: Colors.grey,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Row(
                          children: [
                            Spacer(),
                            Icon(
                              Icons.delete_outlined,color: Colors.white,size: 32,
                            ),
                          ],
                        ),
                      ),
                      child: Stack(
                        children: [
                          CartCard(cart: demoCarts[index]),
                          Align(alignment: Alignment.topRight,child: IconButton(onPressed: (){

                            setState(() {
                          demoCarts.removeAt(index);
                        });

                          }, icon: Icon(
                            Icons.close_outlined,
                          ),),),
                          Padding(
                            padding: const EdgeInsets.only(top: 50.0,right: 25),
                            child: Align(alignment: Alignment.bottomRight,child: DropdownButton(items: [DropdownMenuItem(child: Text('1'),value: '1',),DropdownMenuItem(child: Text('2'),value: '2',),DropdownMenuItem(child: Text('3'),value: '3',),], onChanged: (String? v){setState(() {
                              _selectedItem=v;
                            });},value: _selectedItem,),),
                          )
                        ],
                      ),
                    ),
                  ),


                ),

              ),
            ),

            Container(height:180,width: SizeConfig.screenWidth,child: CheckoutCard()),
          ],
        ),
      ),
    );
  }
}