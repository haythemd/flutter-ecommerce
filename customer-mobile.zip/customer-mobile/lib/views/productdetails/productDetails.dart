import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rivver/customWidgets/bottomNavBars/bottomNavBar.dart';
import 'package:rivver/customWidgets/product/SizeRadio.dart';
import 'package:rivver/models/product.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';
import 'package:rivver/views/productdetails/components/color_dots.dart';
import 'package:rivver/views/productdetails/components/productInfo.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';

class ProductDetails extends StatefulWidget {
  const ProductDetails({Key? key, required this.tag}) : super(key: key);
  final double tag;
  @override
  _ProductDetailsState createState() => _ProductDetailsState();
}

class _ProductDetailsState extends State<ProductDetails> {
  SwiperController swiperController = SwiperController();

  BorderRadiusGeometry radius = BorderRadius.only(
    topLeft: Radius.circular(24.0),
    topRight: Radius.circular(24.0),
  );
  late PanelController panelController;
  @override
  void initState() {

    panelController= PanelController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: Colors.white,
      body: Column(children: [

        Flexible(
          child: SingleChildScrollView(child: Column(

            mainAxisAlignment: MainAxisAlignment.start,
            children: [
            Container(
              decoration: BoxDecoration(
                  color: Color(0xE5EEEEEE),
                  borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(32),
                      bottomLeft: Radius.circular(32))),
              height: 500,
              child: Center(
                child: Hero(
                  tag: this.widget.tag,
                  child: Stack(
                    children: [
                      Swiper(
                        controller: swiperController,
                        layout: SwiperLayout.DEFAULT,
                        fade: 0.2,
                        itemCount: 5,
                        itemBuilder: (context, int) => Image.asset(
                          'assets/images/tshirt.png',
                          fit: BoxFit.contain,
                        ),
                        loop: false,
                        indicatorLayout: PageIndicatorLayout.DROP,
                      ),
                      Align(
                        alignment: Alignment.topLeft,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 20, left: 10),
                          child: Material(
                            color: Colors.transparent,
                            child: IconButton(
                              icon: Icon(
                                Icons.arrow_back_ios_outlined,
                                size: 32,
                              ),
                              onPressed: () {
                                Navigator.pop(context);
                              },
                            ),
                          ),
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            ),...productInfo()



          ],),),
        ),Container(

          decoration: BoxDecoration(
            color: Colors.transparent,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(24.0),
                topRight: Radius.circular(24.0)),
          ),
          padding: EdgeInsets.symmetric(vertical: 5),
          child: MaterialButton(


            color: onyx,
            minWidth: 250,
            height: 40,
            onPressed: () {
              panelController.open();
            },
            child: Text(
              'ADD TO BAG',
              style: segoeWhiteSmall,
            ),
            elevation: 8,
          ),
        ),





      ]


      ),
      bottomNavigationBar: MainNavBar(),
    );
  }
}
