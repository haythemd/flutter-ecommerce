import 'package:flutter/material.dart';
import 'package:rivver/customWidgets/product/compareWidget.dart';
import 'package:rivver/style/themes.dart';


class ProductCompare extends StatefulWidget {
  const ProductCompare({Key? key}) : super(key: key);

  @override
  _ProductCompareState createState() => _ProductCompareState();
}

class _ProductCompareState extends State<ProductCompare> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: onyx,
        title: Text('COMPARE'),
        centerTitle: true,
       automaticallyImplyLeading: true,
      ),
      body: Row(children: [
        CompareWidget(),
        CompareWidget(),
      ],),
    );
  }
}
