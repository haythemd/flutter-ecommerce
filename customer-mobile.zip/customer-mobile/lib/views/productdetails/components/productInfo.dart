import 'package:flutter/material.dart';
import 'package:rivver/customWidgets/product/SizeRadio.dart';
import 'package:rivver/models/product.dart';
import 'package:rivver/style/fonts.dart';
import 'color_dots.dart';
Product product=demoProducts[0];
List<Widget> productInfo() {
  return [
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18.0,vertical: 5),
      child: Text(
        product.title,
        style: nexaBoldBlack,
        textAlign:TextAlign.left,
      ),
    ),
    Text(
      product.description,
      style: nexaTextBlack,
    ),
    Divider(
      thickness: 1.8,
    ),
    Text(
      product.price.toString(),
      style: segoeRedSmall,
    ),
    Divider(
      thickness: 1.8,
    ),
    //getAvailableSizes
    Row(
      children: [
        Text(
          'SIZE: ',
          style: nexaBoldBlack,
        ),
        Text(
          'Small',
          style: segoeBlack18,
        )
      ],
    ),
    SizedBox(
      height: 10,
    ),
    SizeRadio(),
    SizedBox(
      height: 20,
    ),
    Divider(color: Colors.grey, thickness: 1.8),
    Row(
      children: [
        Text(
          'COLOR: ',
          style: nexaBoldBlack,
        ),
      ],
    ),
    ColorDots(product: demoProducts[0]),
    Text(
      '  Delivery & Returns',
      style: segoeBlack18,
    ),
    Divider(
      color: Colors.grey,
      thickness: 1.8,
    ),
    Row(
      children: [
        Icon(
          Icons.storefront_outlined,
          size: 38,
        ),
        Text(
          '  Spacio',
          style: segoeBlackBig,
        ),
        Spacer(),
        TextButton(
          child: TextButton(
              onPressed: () {},
              child: Text(
                'Visit Store',
                style: segoeSmallGreen,
              )),
          onPressed: () {},
        ),
      ],
    ),
  ];
}
