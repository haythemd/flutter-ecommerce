import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../size_config.dart';


class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin{
  late AnimationController controller;
  bool isOpace = true;
  @override
  void initState() {
      controller = AnimationController(
        animationBehavior: AnimationBehavior.preserve,
        value: 0,
        upperBound: 1.0,
        duration: Duration(milliseconds: 1000),
        vsync: this,
      )..animateTo(1);


    super.initState();
  }
  @override
  void didChangeDependencies() {
    SizeConfig().init(context);
    super.didChangeDependencies();
  }
  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(alignment: Alignment.center, children: [
      SizedBox.expand(
        child: Container(
          color: Colors.black,
        ),
      ),
      Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            child: Stack(
              children: [

                Column(
                  children: [
                    InkWell(onTap:(){
                      Navigator.pushReplacementNamed(context, 'home');
                    },
                      child: SvgPicture.asset(
                        'assets/icons/mainLogo.svg',

                        width: MediaQuery.of(context).size.width * 0.6,
                      ),
                    ),

                  ],
                ),
              ],
            ),
          ),

        ],
      ),
    ]));
  }
}
