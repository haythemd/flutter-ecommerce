import 'package:flutter/material.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';

class OrdersPage extends StatefulWidget {
  const OrdersPage({Key? key}) : super(key: key);

  @override
  _OrdersPageState createState() => _OrdersPageState();
}

class _OrdersPageState extends State<OrdersPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('DETAILS'),
        centerTitle: true,
        leadingWidth: 30,
        backgroundColor: onyx,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: Icon(
            Icons.arrow_back_ios_new,
            size: 28,
          ),
        ),
      ),
      body:Column(crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: 50,),
        Padding(
          padding: const EdgeInsets.all(18.0),
          child: Stack(
            alignment: Alignment.center,
            children: [
            CircleAvatar(backgroundColor: Color(0xFFEEEEEE),minRadius: 120,),
            Icon(
              Icons.shopping_bag,size: 150,
            ),
              Positioned(top: 10, right: 70,
                child: Icon(
                  Icons.auto_awesome_outlined,size: 50,
                ),
              ),
          ],),
        ),
          Text("You don't have any\norders yet",style: segoeBlackBold,textAlign: TextAlign.center,),
          Container(
              padding: EdgeInsets.symmetric(horizontal: 20,vertical: 40),
              child: MaterialButton(
                onPressed: () {
                  Navigator.of(context).pushReplacementNamed('home');
                },
                height: 40,
                color: Colors.black,
                minWidth: 300,

                child: Text(
                  'Start Shopping',
                  style: segoeWhiteSmall,
                ),
              )),
      ],),
    );
  }
}
