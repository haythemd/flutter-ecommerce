import 'package:flutter/material.dart';
import 'package:rivver/customWidgets/bottomNavBars/bottomNavBar.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';

class UserProfile extends StatefulWidget {
  const UserProfile({Key? key}) : super(key: key);

  @override
  _UserProfileState createState() => _UserProfileState();
}

class _UserProfileState extends State<UserProfile> {
  Map<String,String> choiceList = {
    'Account Info':'account details',
    'My Orders':'orders',
    'My Reviews':'reviews',
    'My Wallet':'wallet',
    'FAQ':'faq',
    'Privacy Policy':'policy',
    'About':'about',
    'Contact Us':'contact'
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'ACCOUNT',
        ),
        centerTitle: true,
        backgroundColor: onyx,
      ),
      backgroundColor: Colors.grey,
      body: Container(color: Colors.white,
        child: Column(children: [
          SizedBox(height: 15,child: Container(color: Color(0xFFDDDDDD),),),
         Flexible(flex: 1,
           child: ListTile(trailing: Icon(
        Icons.arrow_forward_ios_outlined,color: Colors.black,
        ),title: Text('Account Info',style: segoeBlack18,),onTap: ()=> Navigator.of(context).pushNamed('account details'),
           leading: Icon(
             Icons.login_outlined,color: Colors.black,
           ),),

         ),
        Divider(thickness:1.5),
          Flexible(flex: 1,
            child: ListTile(trailing: Icon(
              Icons.arrow_forward_ios_outlined,color: Colors.black,
            ),leading: Text('My Orders',style: segoeBlack18,),onTap: ()=> Navigator.of(context).pushNamed('orders'),),
          ),
          Divider(thickness:1.5),
          Flexible(flex: 1,
            child: ListTile(trailing: Icon(
              Icons.arrow_forward_ios_outlined,color: Colors.black,
            ),leading: Text('My Reviews',style: segoeBlack18,),onTap: ()=> Navigator.of(context).pushNamed('reviews'),),
          ),
          Divider(thickness:1.5),
          Flexible(flex: 1,
            child: ListTile(trailing: Icon(
              Icons.arrow_forward_ios_outlined,color: Colors.black,
            ),leading: Text('My Wallet',style: segoeBlack18,),onTap: ()=> Navigator.of(context).pushNamed('wallet'),),
          ),
          SizedBox(height: 15,child: Container(color: Color(0xFFDDDDDD),),),
          Flexible(flex: 1,
            child: ListTile(trailing: Icon(
              Icons.arrow_forward_ios_outlined,color: Colors.black,
            ),leading: Text('FAQ',style: segoeBlack18,),onTap: ()=> Navigator.of(context).pushNamed('faq'),),
          ),
          Divider(thickness:1.5),
          Flexible(flex: 1,
            child: ListTile(trailing: Icon(
              Icons.arrow_forward_ios_outlined,color: Colors.black,
            ),leading: Text('Privacy Policy',style: segoeBlack18,),onTap: ()=> Navigator.of(context).pushNamed('policy'),),
          ),
          Divider(thickness: 1.5,),
          Flexible(flex: 1,
            child: ListTile(trailing: Icon(
              Icons.arrow_forward_ios_outlined,color: Colors.black,
            ),leading: Text('About',style: segoeBlack18,),onTap: ()=> Navigator.of(context).pushNamed('about'),),
          ),
          Divider(thickness:1.5),
          Flexible(flex: 1,
            child: ListTile(trailing: Icon(
              Icons.arrow_forward_ios_outlined,color: Colors.black,
            ),leading: Text('Contact Us',style: segoeBlack18,),onTap: ()=> Navigator.of(context).pushNamed('contact'),),
          ),
          SizedBox(height: 15,child: Container(color: Color(0xFFDDDDDD),),),

          Flexible(flex: 1,
            child: ListTile(
            leading: Text('Version 10.6.1',style: segoeBlack18,),onTap: (){},),
          ),

      ],)
      ),
      bottomNavigationBar: MainNavBar(),
    );
  }
}
