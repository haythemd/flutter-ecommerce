import 'package:flutter/material.dart';
import 'package:rivver/customWidgets/bottomNavBars/bottomNavBar.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';

class AccountInfo extends StatefulWidget {
  const AccountInfo({Key? key}) : super(key: key);

  @override
  _AccountInfoState createState() => _AccountInfoState();
}

class _AccountInfoState extends State<AccountInfo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('DETAILS'),
        centerTitle: true,
        leadingWidth: 30,
        backgroundColor: onyx,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: Icon(
            Icons.arrow_back_ios_new,
            size: 28,
          ),
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            color: Color(0xFFEEEEEE),
            height: 40,
            padding: const EdgeInsets.only(left: 20),
            child: Row(
              children: [
                Text(
                  'ACCOUNT INFORMATIONS',
                  style: gothicBlackSmall,
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.only(left: 20),
            child: Text(
              '\nE-mail: someone@gmail.com\nName: Hisham Elkahwagy\nBirthday: 19-19-1919\n',
              style: segoeBlackSmall,
            ),
          ),
          Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: MaterialButton(
                onPressed: () {},
                height: 40,
                color: Colors.black,
                minWidth: 6000,
                child: Text(
                  'Edit',
                  style: segoeWhiteSmall,
                ),
              )),
          Container(
            color: Color(0xFFEEEEEE),
            height: 40,
            padding: const EdgeInsets.only(left: 20),
            margin: EdgeInsets.only(top: 10),
            child: Row(
              children: [
                Text(
                  'ADDRESSES',
                  style: gothicBlackSmall,
                ),
              ],
            ),
          ),
          Divider(),
          Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: MaterialButton(
                onPressed: () {},
                height: 40,
                color: Colors.black,
                minWidth: 6000,
                child: Text(
                  'Edit',
                  style: segoeWhiteSmall,
                ),
              )),
          Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: MaterialButton(
                onPressed: () {},
                height: 40,
                color: Colors.black,
                minWidth: 6000,
                child: Text(
                  'Add New Address',
                  style: segoeWhiteSmall,
                ),
              )),
        ],
      ),
      bottomNavigationBar: MainNavBar(),
    );
  }
}
