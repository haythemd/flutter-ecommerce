import 'package:flutter/material.dart';
import 'package:rivver/customWidgets/backButton/backButton.dart';
import 'package:rivver/customWidgets/searchButton/searchButton.dart';
import 'package:rivver/style/themes.dart';


class FollowDetailsPage extends StatefulWidget {
  static const String pageID = 'FollowDetailsPage';
  const FollowDetailsPage({Key? key}) : super(key: key);

  @override
  State<FollowDetailsPage> createState() => _FollowDetailsPageState();
}

class _FollowDetailsPageState extends State<FollowDetailsPage> {
  final TextEditingController _textEditingController = TextEditingController();
  bool searchIconVisible = true;
  // bool follow = true;
  List<bool> follow = [true, true, true, true, true, true, true];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 10),
              //! Back Button
              BackButtonCustom(ontap: () {
                Navigator.pop(context);
              }),
              const SizedBox(height: 20),
              Text('Followers', style: textTheme(context).headline1!.copyWith(fontSize: 20)),
              const SizedBox(height: 10),
              //! Search Box
              SearchBoxWidget(
                ontap: () {
                  setState(() {
                    searchIconVisible = !searchIconVisible;
                  });
                },
                onEditingComplete: () {},
                onChange: (value) {},
                visible: searchIconVisible,
                controller: _textEditingController,
              ),
              const SizedBox(height: 20),
              //! List OF Followers / Followings
              Expanded(
                child: ListView.builder(
                  itemBuilder: (context, index) {
                    return CircleAvatar();
                  },
                  itemCount: follow.length,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}