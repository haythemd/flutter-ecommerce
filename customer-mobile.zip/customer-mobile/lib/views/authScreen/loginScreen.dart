import 'package:flutter/material.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  late TextEditingController emailController;
  late TextEditingController passController;
  bool checked = false;
  @override
  void initState() {
    emailController = TextEditingController(text: 'Email Address');
    passController = TextEditingController(text: 'Password');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text('LOGIN'),
        centerTitle: true,
        leadingWidth: 30,
        backgroundColor: onyx,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: Icon(
            Icons.arrow_back_ios_new,
            size: 28,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 28.0),
        child: Column(
          children: [
            Container(
              height: 40,
              width: 280,
              margin: EdgeInsets.only(bottom: 10, top: 10),
              child: ElevatedButton(
                onPressed: null,
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Image.asset(
                        'assets/icons/fb.png',
                        fit: BoxFit.scaleDown,
                      ),
                      Spacer(),
                      Text(
                        'Continue with Facebook',
                        style: segoeWhiteSmall,
                      ),
                      Spacer()
                    ],
                  ),
                ),
                style: ButtonStyle(
                    backgroundColor:
                        MaterialStateProperty.all(Colors.blueAccent)),
              ),
            ),
            Container(
              height: 40,
              width: 280,
              margin: EdgeInsets.only(bottom: 10),
              child: ElevatedButton(
                onPressed: null,
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Image.asset('assets/icons/google.png'),
                      Spacer(),
                      Text(
                        'Continue with Google',
                        style: segoeBlackSmall,
                      ),
                      Spacer()
                    ],
                  ),
                ),
                style: ButtonStyle(side: MaterialStateProperty.all(BorderSide(color: onyx,)),
                    backgroundColor:
                        MaterialStateProperty.all(Colors.white)),
              ),
            ),
            Container(
              height: 40,
              width: 280,
              margin: EdgeInsets.only(bottom: 10),
              child: ElevatedButton(
                  onPressed: null,
                  child: Padding(
                    padding: const EdgeInsets.all(4.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Image.asset(
                          'assets/icons/apple.png',
                          fit: BoxFit.fitHeight,
                        ),
                        Spacer(),
                        Text(
                          'Continue with Apple',
                          style: segoeWhiteSmall,
                        ),
                        Spacer(),
                      ],
                    ),
                  ),
                  style: ButtonStyle(
                      backgroundColor:
                          MaterialStateProperty.all(Colors.black))),
            ),
            Row(
              children: [
                Expanded(
                    child: Divider(
                  thickness: 2,
                  endIndent: 5,
                )),
                Text(
                  'OR',
                  style: gothicBlackSmall,
                ),
                Expanded(
                    child: Divider(
                  indent: 5,
                  thickness: 2,
                )),
              ],
            ),
            Container(
              height: 40,
              width: 280,
              margin: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              padding: EdgeInsets.only( top: 10,left: 10),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(2),
                  border: Border.all(color: onyx, width: 0.5),
                  ),
              child: TextFormField(
                controller: emailController,
                decoration: InputDecoration.collapsed(hintText: 'Email Address'),
              ),
            ),
            Container(
                height: 40,
                width: 280,
                margin: EdgeInsets.symmetric(horizontal: 20),
                padding: EdgeInsets.only(top: 10, left: 10),
                child: TextFormField(
                  controller: passController,
                  obscureText: true,
                ),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(2),
                    border: Border.all(color: onyx, width: 0.5),
                    )),
            Text('Continue with your email'),
            Padding(
              padding:
                  const EdgeInsets.only(top: 8.0, left: 18,bottom: 10,right: 50),
              child: Row(
                children: [
                  Checkbox(
                      value: checked,
                      onChanged: (i) {
                        setState(() {
                          if (checked) {
                            checked = false;
                          } else {
                            checked = true;
                          }
                        });
                      }),
                  Expanded(
                    child: Text(
                      'I want to access exclusive deals, I agree on terms and Other things',
                      style: nexaTextBlack,
                    ),
                  )
                ],
              ),
            ),
            Container(
                height: 40,
                width: 280,
                child: ElevatedButton(
                  onPressed: () {},
                  child: Text(
                    'Login',
                    style: segoeBlackSmall,
                  ),
                  style: ElevatedButton.styleFrom(elevation: 0,
                      primary: Color(0x30B9B9B9),
                      ),
                )),
            Padding(
              padding: const EdgeInsets.only(right: 20.0),
              child: Align(
                child: TextButton(
                  onPressed: () {
                    Navigator.of(context).pushNamed('resetPassword');
                  },
                  child: Text(
                    'Forgot Password?',
                    style: segoeSmallGreen,
                  ),
                ),
                alignment: Alignment.centerRight,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: RichText(textAlign: TextAlign.center,
                  text: TextSpan(style: segoeBlackSmall, children: <TextSpan>[
                TextSpan(
                    text:
                        'By creating an account or signing in, you agree on our ',
                    style: loraBlackSmall),
                TextSpan(text: 'Terms & Conditions', style: segoeSmallGreen,),
                TextSpan(text: ' & ', style: loraBlackSmall),
                TextSpan(text: 'Privacy Policy', style: segoeSmallGreen,),
              ])),
            ),
            Text(
              "Dont have an Account?",
              style: segoeBlackSmall,
            ),
            Expanded(
                child: TextButton(
                    onPressed: () {
                      Navigator.of(context).pushNamed('register');
                    },
                    child: Text('Register Now'))),
          ],
        ),
      ),
    );
  }
}
