import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';

class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  _RegisterState createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  late TextEditingController emailController;
  late TextEditingController passController;
  late TextEditingController passConfirmController;
  bool checked = false;

  @override
  void initState() {
    emailController = TextEditingController(text: 'Email Address');
    passController = TextEditingController(text: 'Password');
    passConfirmController = TextEditingController(text: 'Confirm');

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text('REGISTER'),
        leadingWidth: 30,
        centerTitle: true,
        backgroundColor: onyx,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: Icon(
            Icons.arrow_back_ios_new,
            size: 28,
          ),
        ),
      ),
      body: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 48.0),
              child: Text('Sign Up With E-mail\n',
                  style:
                      GoogleFonts.bebasNeue(fontSize: 32, color: Colors.black)),
            ),
            Container(
              height: 40,
              width: 280,
              margin: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              padding: EdgeInsets.only(top: 10, left: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: onyx, width: 0.5),
              ),
              child: TextFormField(
                controller: emailController,
                decoration:
                    InputDecoration.collapsed(hintText: 'E-mail Address'),
              ),
            ),
            Container(
              height: 40,
              width: 280,
              margin: EdgeInsets.symmetric(horizontal: 20),
              padding: EdgeInsets.only(top: 10, left: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: onyx, width: 0.5),
              ),
              child: TextFormField(
                controller: passController,
                decoration: InputDecoration.collapsed(hintText: 'Password'),
              ),
            ),
            Container(
              height: 40,
              width: 280,
              margin: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              padding: EdgeInsets.only(top: 8, left: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: onyx, width: 0.5),
              ),
              child: TextFormField(
                controller: passConfirmController,
                decoration:
                    InputDecoration.collapsed(hintText: 'Confirm Password'),
              ),
            ),
            Padding(
              padding:
              const EdgeInsets.only(top: 8.0, left: 45,bottom: 10,right: 50),
              child: Row(
                children: [
                  Checkbox(
                      value: checked,
                      onChanged: (i) {
                        setState(() {
                          if (checked) {
                            checked = false;
                          } else {
                            checked = true;
                          }
                        });
                      }),
                  Expanded(
                    child: Text(
                      'I want to access exclusive deals, I agree on terms and other things',
                      style: nexaTextBlack,
                    ),
                  )
                ],
              ),
            ),
            MaterialButton(
              minWidth: 280,
              height: 40,
              color: Colors.black,
              onPressed: () {
                Navigator.pushReplacementNamed(context, 'firstSignIn');
              },
              child: Text(
                'Sign Up',
                style: GoogleFonts.bebasNeue(fontSize: 30, color: Colors.white),
              ),
            ),
            Divider(),
            SizedBox(
              height: 50,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  height: 60,
                  width: 60,
                  margin: EdgeInsets.only(bottom: 10, top: 10),
                  child: ElevatedButton(
                    onPressed: (){Navigator.pushNamed(context, 'profile');},
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Image.asset(
                        'assets/icons/fb.png',
                        fit: BoxFit.contain,
                      ),
                    ),
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                        backgroundColor:
                            MaterialStateProperty.all(Color(0xFF434b94))),
                  ),
                ),
                Container(
                  height: 60,
                  width: 60,
                  child: ElevatedButton(
                    onPressed: null,
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Image.asset(
                        'assets/icons/apple.png',
                        fit: BoxFit.scaleDown,
                      ),
                    ),
                    style: ButtonStyle(
                 shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                        backgroundColor: MaterialStateProperty.all(onyx)),
                  ),
                ),
                Container(
                  height: 60,
                  width: 60,
                  margin: EdgeInsets.only(bottom: 10, top: 10),
                  child: ElevatedButton(
                    onPressed: null,
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Image.asset(
                        'assets/icons/google.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    style: ButtonStyle(shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                        backgroundColor:
                            MaterialStateProperty.all(Colors.white)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}