import 'package:csc_picker/csc_picker.dart';
import 'package:flutter/material.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';

class FirstSignInPage extends StatefulWidget {
  const FirstSignInPage({Key? key}) : super(key: key);

  @override
  _FirstSignInPageState createState() => _FirstSignInPageState();
}

class _FirstSignInPageState extends State<FirstSignInPage> {
  String? countryValue,stateValue,cityValue ;
  DateTime? birthday;
  TextEditingController fullname = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('SIGN UP'),centerTitle: true,automaticallyImplyLeading: false,backgroundColor: onyx,),
      body: Container(margin: EdgeInsets.all(20),child:Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('One More Step!',style: gothicBlack24,),
          Divider(thickness: 1,),

         Text('Tell Us More About Yourself',style: segoeBlack18,),

          Container(
            height: 40,
            width: 400,
            margin: EdgeInsets.symmetric( vertical: 20),
            padding: EdgeInsets.only(top: 10, left: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: onyx, width: 0.5),
            ),
            child: TextFormField(
              controller: fullname,
              decoration:
              InputDecoration.collapsed(hintText: 'Full Name'),
            ),
          ),

        Divider(thickness: 1,),




         Text('Select Your Location\n',style: segoeBlack18,),
         CSCPicker(selectedItemStyle: segoeBlack18,
         dropdownItemStyle: segoeBlack18,
           onCountryChanged: (value) {
             setState(() {
               countryValue = value;
             });
           },
           onStateChanged:(value) {
             setState(() {
               stateValue = value;
             });
           },
           onCityChanged:(value) {
             setState(() {
               cityValue = value;
             });
           },

         ),
          Divider(thickness: 1,),
          Text('Select Your Birthday\n',style: segoeBlack18,),
          Center(
            child: MaterialButton(color: Colors.grey,height: 40,minWidth: 400,
              child: Text('Select Birthday',style: segoeBlackBig,),
              onPressed: (){
              showDialog(context: context, builder: (BuildContext context){return Dialog(child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,children: [
                  CalendarDatePicker(
                      initialDate: DateTime(2010), firstDate: DateTime(1900), lastDate: DateTime.now(), onDateChanged: (date){
                    setState(() {
                      birthday=date;
                    });
                  }),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: MaterialButton(onPressed: (){Navigator.of(context).pop();},color: onyx,child: Text('Confirm',style: segoeWhiteSmall,),),
                  )
                ],
              ), );});
            },),

          ),Divider(thickness: 1,),
          Spacer(),
          Padding(
            padding: const EdgeInsets.only(bottom: 40.0),
            child: MaterialButton(onPressed: (){Navigator.of(context).pushReplacementNamed('home');},child: Text('Finish',style: segoeWhiteSmall,),height: 40,minWidth: 400,color: onyx,),
          )

        ],
      ) ,),
    );
  }
}
