import 'package:flutter/material.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';


class ResetPassword extends StatefulWidget {
  const ResetPassword({Key? key}) : super(key: key);

  @override
  _ResetPasswordState createState() => _ResetPasswordState();
}

class _ResetPasswordState extends State<ResetPassword> {

  late TextEditingController emailController;
  late TextEditingController passController;
  bool checked = false;

  @override
  void initState() {
    emailController = TextEditingController(text: 'Email Address');
    passController = TextEditingController(text: 'Password');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(
      title: Text('BACK'),
      leadingWidth: 30,
      centerTitle: true,
      backgroundColor: onyx,
      leading: IconButton(
        onPressed: () {
          Navigator.of(context).pop();
        },
        icon: Icon(
          Icons.arrow_back_ios_new,
          size: 28,
        ),
      ),
    ),
    backgroundColor: Colors.white,
    body: Center(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            height: 40,width: 280,
            margin: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            padding: EdgeInsets.only(bottom: 5,left: 10),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: onyx, width: 1),
                boxShadow: [
                  BoxShadow(color: onyx, spreadRadius: 0.2, blurRadius: 3)
                ]),
            child: TextFormField(controller: emailController,),
          ),
          Container(height: 40,width: 280,child: ElevatedButton(onPressed: () {}, child: Text('Login',style: segoeBlackSmall,),
            style: ElevatedButton.styleFrom(primary: Color(0xE0E0E0FF)),)),
        ],
      ),
    ),

    );
  }
}
