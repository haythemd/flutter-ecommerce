//HomePage Constants

import 'package:flutter/material.dart';
import 'package:rivver/views/authScreen/firstSignIn.dart';
import 'package:rivver/views/authScreen/forgotPassword.dart';
import 'package:rivver/views/authScreen/loginScreen.dart';
import 'package:rivver/views/authScreen/registerScreen.dart';
import 'package:rivver/views/bag/bag.dart';
import 'package:rivver/views/brands/followPage.dart';
import 'package:rivver/views/categories/categories.dart';
import 'package:rivver/views/favorites/favorites.dart';
import 'package:rivver/views/home/homePage.dart';
import 'package:rivver/views/landingPage.dart';
import 'package:rivver/views/productdetails/productCompare.dart';
import 'package:rivver/views/productdetails/productDetails.dart';
import 'package:rivver/views/userProfile/accountInfo.dart';
import 'package:rivver/views/userProfile/orderPage.dart';
import 'package:rivver/views/userProfile/userProfile.dart';
import 'package:rivver/views/wallet/wallet.dart';

List<String> clothingCategories = ['Shirts','Pants','Dresses','Coats', 'Jackets','Shoes','Outerwear','lingerie','Accessories'];
List<String> brandsLogos = ['assets/images/nike.png','assets/images/adidas.png','assets/images/nike.png','assets/images/adidas.png','assets/images/nike.png','assets/images/adidas.png'];

const EdgeInsets kPaddingAll = EdgeInsets.all(18);
const EdgeInsets kPaddingSides = EdgeInsets.symmetric(horizontal: 18);

 List<String> categories= ['assets/images/catBanner1.jpg','assets/images/catBanner2.jpeg','assets/images/catBanner3.jpg','assets/images/catBanner4.jpg','assets/images/catBanner5.jpg','assets/images/catBanner6.jpg',] ;




const BorderRadius ellipticalBorder = BorderRadius.only(
bottomLeft: Radius.elliptical(35, 16),
bottomRight: Radius.elliptical(35, 16),
);

Map<String, Widget Function(BuildContext)> routes = {
'login' : (context) => LoginScreen(),
'home': (context) => Directionality(
textDirection: TextDirection.ltr, child: HomePage()),
'splash': (context) => SplashScreen(),
'productDetails': (context) => ProductDetails(tag: 1,),
'categories': (context) => CategoriesPage(),
'profile' : (context) => UserProfile(),
'resetPassword': (context) => ResetPassword(),
'register' :(context) => Register(),
'account details' : (context) => AccountInfo(),
'orders' :(context)=> OrdersPage(),
'favorites': (context) => FavoritesTrue(),
'firstSignIn' :(context) => FirstSignInPage(),
'wallet': (context) => WalletPage(),
'productCompare': (context) => ProductCompare(),
'brandFollow': (context) => FollowDetailsPage(),
 'bag' : (context) => CartScreen(),
};

class ProductItems {
 final String title;
 ProductItems(this.title);


}