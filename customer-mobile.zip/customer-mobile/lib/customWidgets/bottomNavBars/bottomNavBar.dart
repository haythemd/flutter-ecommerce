import 'package:convex_bottom_bar/convex_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:rivver/style/themes.dart';

class MainNavBar extends StatefulWidget {
  const MainNavBar({Key? key}) : super(key: key);

  @override
  _MainNavBarState createState() => _MainNavBarState();
}

class _MainNavBarState extends State<MainNavBar> {

  bool guest = true;

  @override
  Widget build(BuildContext context) {
    return ConvexAppBar.badge(
      {},
      elevation: 20,
      height: 80,
      top: null,
      initialActiveIndex: 2,
      style: TabStyle.reactCircle,
      backgroundColor: onyx,
      color: Colors.white,
      activeColor: onyx,
      curve: Curves.easeInExpo,
      curveSize: 22,
      items: [
        TabItem(
          icon: Icon(
            Icons.format_list_bulleted_outlined,
            color: Colors.white,
            size: 28,
          ),
        ),
        TabItem(
          icon: Icon(
            Icons.shopping_bag_outlined,
            color: Colors.white,
            size: 28,
          ),
        ),
        TabItem(icon: Image.asset('assets/icons/bottom1.png'), title: 'Rvver'),
        TabItem(
          icon: Icon(
            Icons.favorite_border_outlined,
            color: Colors.white,
            size: 28,
          ),

        ),
        TabItem(
          icon: Icon(
            Icons.person_outlined,
            color: Colors.white,
            size: 28,
          ),
        ),

      ],onTap: (index){
      switch (index) {
        case 0 :{
          Navigator.of(context).pushReplacementNamed('bag');
      }
      break;
        case 1:{
          Navigator.of(context).pushReplacementNamed('profile');
        }
        break;
        case 2:{
        Navigator.of(context).pushReplacementNamed('home');
        }
        break;
        case 3:{
          Navigator.of(context).pushReplacementNamed('favorites');
        }
        break;
        case 4:{
          if (guest){


            Navigator.of(context).pushReplacementNamed('login');
            setState(() {
              guest=false;
            });


          }
          else {
            Navigator.of(context).pushNamed('profile');

          }



        }
        break;
    }}
    );
  }
}


