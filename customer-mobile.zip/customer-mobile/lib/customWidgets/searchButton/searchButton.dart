import 'package:flutter/material.dart';
import 'package:rivver/deviceHelper/sizes.dart';
import 'package:rivver/style/colors.dart';
import 'package:rivver/style/decorations.dart';

class SearchBoxWidget extends StatelessWidget {
  const SearchBoxWidget({
    Key? key,
    required this.controller,
    required this.onChange,
    required this.ontap,
    required this.visible,
    required this.onEditingComplete,
  }) : super(key: key);
  final VoidCallback ontap;
  final VoidCallback onEditingComplete;
  final Function(String) onChange;
  final TextEditingController controller;
  final bool visible;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
      decoration: searchWidgetDecoration.copyWith(
        color: colorScheme(context).secondaryVariant,
      ),
      child: Row(
        children: [
          Visibility(
            visible: visible,
            child: const Icon(Icons.search_outlined, color: primaryColor),
          ),
          Flexible(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5),
              child: SizedBox(
                width: deviceWidth(context),
                child: TextField(
                  maxLines: 1,
                  decoration: const InputDecoration(hintText: 'Search'),
                  controller: controller,
                  onChanged: onChange,
                  onTap: ontap,
                  onEditingComplete: onEditingComplete,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
