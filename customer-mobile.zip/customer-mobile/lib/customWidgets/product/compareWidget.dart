import 'package:flutter/material.dart';

class CompareWidget extends StatefulWidget {
  const CompareWidget({Key? key}) : super(key: key);

  @override
  _CompareWidgetState createState() => _CompareWidgetState();
}

class _CompareWidgetState extends State<CompareWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width/2.1,
      child: Column(
        children: [
          Container(
            child: Image.asset('assets/images/product.png'),
          ),
          Divider(),
          Container(
            
          )
        ],
      ),

    );
  }
}
