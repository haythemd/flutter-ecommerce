
import 'package:flutter/material.dart';
import 'package:rivver/style/fonts.dart';

class SizeRadio extends StatefulWidget {
  const SizeRadio({Key? key}) : super(key: key);

  @override
  _SizeRadioState createState() => _SizeRadioState();
}

class _SizeRadioState extends State<SizeRadio> {
  List<String> sizes = ['S', 'M','L','XL','XXL'];
  String selectedSize ='';
  @override
  Widget build(BuildContext context) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,children: [
      ...sizes.map((e) => InkWell(onTap: ()=> setState(() {
        selectedSize=e;
      }),child: Container(height: 50,width: 50,decoration: BoxDecoration(shape: BoxShape.circle,border: Border.all(width: 2.7,color: selectedSize==e?Colors.blue:Colors.black)),child: Center(child: Text(e,style: segoeBlackSmall,)),)),)

    ],);
  }
}
