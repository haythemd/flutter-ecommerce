import 'package:flutter/material.dart';
import 'package:rivver/style/colors.dart';

class BackButtonCustom extends StatelessWidget {
  const BackButtonCustom({
    Key? key,
    required this.ontap,
    this.color,
    this.size,
  }) : super(key: key);
  final VoidCallback ontap;
  final Color? color;
  final double? size;
  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: IconButton(
        onPressed: ontap,
        icon: const Icon(Icons.arrow_back_ios_outlined),
        color: color ?? secondaryColor,
        iconSize: size ?? 25,
        splashColor: Colors.transparent,
        highlightColor: Colors.transparent,
      ),
    );
  }
}
