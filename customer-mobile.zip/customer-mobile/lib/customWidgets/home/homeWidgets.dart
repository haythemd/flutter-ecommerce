import 'package:flutter/material.dart';

class ImageBanner extends StatelessWidget {
  final String title;
  final String url;
  const ImageBanner({Key? key, required this.title, required this.url})
      : super(key: key);

  String getURL() {
    return url;
  }

  String getTitle() {
    return title;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 300,
      child: SizedBox.expand(
        child: Image.network(
          'https://dkemhji6i1k0x.cloudfront.net/000_clients/84990/page/84990A4MpBhxj.jpg',
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
