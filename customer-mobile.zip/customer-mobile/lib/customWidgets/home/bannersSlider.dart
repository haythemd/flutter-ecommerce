import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/material.dart';

class BannerSlider extends StatefulWidget {
  const BannerSlider({Key? key}) : super(key: key);

  @override
  _BannerSliderState createState() => _BannerSliderState();
}

class _BannerSliderState extends State<BannerSlider> {
  @override
  Widget build(BuildContext context) {
    return SizedBox.fromSize(
        size: Size.fromHeight(300),
        child: Swiper.children(
          autoplay: true,
          transformer: ScaleAndFadeTransformer(),


          children: [
            Image.asset('assets/images/salesBanner.jpg',fit: BoxFit.cover,),
            Image.asset('assets/images/salesBanner1.jpeg',fit: BoxFit.cover,),
            Image.asset('assets/images/salesBanner2.jpg',fit: BoxFit.cover,)
          ],
        ));
  }
}
