import 'package:flutter/material.dart';
import 'package:rivver/constants.dart';
import 'package:rivver/style/fonts.dart';

class BrandSlider extends StatefulWidget {
  const BrandSlider({Key? key}) : super(key: key);

  @override
  _BrandSliderState createState() => _BrandSliderState();
}

class _BrandSliderState extends State<BrandSlider> {
  @override
  Widget build(BuildContext context) {
    return Container(height: 100,color: Color(0xA8F8F8F8),child: SingleChildScrollView(scrollDirection: Axis.horizontal,child: Row(children: [
        ...brandsLogos.map((e) => Container(margin: EdgeInsets.all(8),height: 70,decoration: BoxDecoration(shape: BoxShape.circle),child: Column(
      children: [
        Expanded(child: Image.asset(e)),
        e=='assets/images/adidas.png'?Text('Adidas',style: segoeBlackSmall,):Text('Nike',style: segoeBlackSmall,),
      ],
    ),)),]),));
  }
}
