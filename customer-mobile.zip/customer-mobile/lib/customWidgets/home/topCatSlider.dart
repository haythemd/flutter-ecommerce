import 'package:flutter/material.dart';
import 'package:rivver/constants.dart';
import 'package:rivver/style/fonts.dart';

class TopCategoriesSlider extends StatefulWidget {
  const TopCategoriesSlider({Key? key}) : super(key: key);

  @override
  _TopCategoriesSliderState createState() => _TopCategoriesSliderState();
}

class _TopCategoriesSliderState extends State<TopCategoriesSlider> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(scrollDirection:Axis.horizontal,child: Row(
      children: [
        ...clothingCategories.map((e) =>  Padding(
          padding: const EdgeInsets.only(left: 15.0,bottom: 40),
          child: MaterialButton(height: 50,elevation: 2,shape: ContinuousRectangleBorder(),onPressed: (){}, child: Text(e,style: segoeBlackSmall,),color: Colors.white,),
        ))
      ],
    ),);
  }
}
