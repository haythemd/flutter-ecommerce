import 'package:flutter/material.dart';
import 'package:rivver/style/fonts.dart';

import '../../constants.dart';

class Heading extends StatelessWidget {
  const Heading({Key? key, this.text}) : super(key: key);
  final String? text;

  @override
  Widget build(BuildContext context) {
    return Container(margin: const EdgeInsets.only(top: 35),
      decoration: BoxDecoration(borderRadius: ellipticalBorder,color: Colors.white, boxShadow: [
        BoxShadow(color: Colors.black, )
      ]),
      padding: kPaddingAll,
      child: Align(
          child: Text(
            text!,
            style: segoeBlackBold,
          ),
          alignment: Alignment.topLeft),
    );
  }
}

Widget function (){
  return Container();
}

