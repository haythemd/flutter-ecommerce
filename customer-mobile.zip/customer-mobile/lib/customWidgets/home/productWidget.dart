import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:rivver/constants.dart';
import 'package:rivver/customWidgets/home/promoWidget.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';
import 'package:rivver/views/productdetails/productDetails.dart';

class ProductWidget extends StatefulWidget {
  const ProductWidget(
      {Key? key, this.promoUrl, this.promoCode, this.description,required this.tag})
      : super(key: key);
  final String? promoUrl;
  final double tag;
  final String? promoCode;
  final String? description;
  @override
  _ProductWidgetState createState() => _ProductWidgetState();
}

class _ProductWidgetState extends State<ProductWidget> {

  @override

  Widget build(BuildContext context) {
    return Container(


      margin: kPaddingSides,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Flexible(
            flex: 4,
            child: Stack(
              alignment: Alignment.topLeft,
              children: [
                GestureDetector(
                  child: Hero(tag:this.widget.tag,
                    child: Image.asset(
                      'assets/images/tshirt.png',
                      fit: BoxFit.contain,
                    ),
                  ),onTap: (){
                    Navigator.of(context).push(PageRouteBuilder(pageBuilder: (_,__,___){return ProductDetails(tag: this.widget.tag);},transitionDuration: Duration(milliseconds: 1500)));
                },
                ),
                this.widget.promoUrl == null ? SizedBox.shrink() : PromoWidget()
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: [
              Text(
                'T-Shirt',
                style: GoogleFonts.archivoNarrow(fontSize: 22, color: onyx),
              ),
              IconButton(
                  onPressed: () {

                  },
                  icon: Icon(
                    Icons.favorite_border_outlined,
                  )),
            ],
          ),
          Container(height: 100,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Black Shirt',
                  style: segoeGreySmall,
                ),
                Text(
                  'EGP 107.90',
                  overflow: TextOverflow.visible,
                  style: segoeRedSmall,
                ),
                Row(mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('EGP 129.00',style: segoeGreySmallLine,),
                    Flexible(child: Text('16% OFF',style: segoeGreySmall,),fit: FlexFit.loose,),
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
