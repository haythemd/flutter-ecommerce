import 'package:flutter/material.dart';
class PromoWidget extends StatelessWidget {
  const PromoWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(height:40,child: Image.asset('assets/icons/sale.png',fit: BoxFit.fitHeight,),);
  }
}
