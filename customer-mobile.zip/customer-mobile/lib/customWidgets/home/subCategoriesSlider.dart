import 'package:flutter/material.dart';
import 'package:rivver/constants.dart';
import 'package:rivver/style/fonts.dart';

class SubCategorySlider extends StatefulWidget {
  const SubCategorySlider({Key? key}) : super(key: key);

  @override
  _SubCategorySliderState createState() => _SubCategorySliderState();
}

class _SubCategorySliderState extends State<SubCategorySlider> {
  @override
  Widget build(BuildContext context) {
    return Container(color: Colors.white,
      child: SizedBox.fromSize(
        size: Size.fromHeight(50),
        child: Container(
          decoration: BoxDecoration(
              shape: BoxShape.rectangle,

              color: Colors.white,
              borderRadius: ellipticalBorder,
              boxShadow: [
                BoxShadow(color: Colors.black, blurRadius: 12, spreadRadius: 1)
              ]),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                ...clothingCategories.map((e) => Padding(
                      child: TextButton(
                          onPressed: () {},
                          child: Column(
                            children: [
                              Text(e, style: gothicBlackSmall),
                            ],
                          )),
                      padding: EdgeInsets.only(left: 8),
                    ))
              ],
            ),
          ),
        ),
      ),
    );
  }
}
