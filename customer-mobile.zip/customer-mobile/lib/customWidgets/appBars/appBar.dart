import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:rivver/customWidgets/home/subCategoriesSlider.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';

import '../../constants.dart';

class CustomAppBar extends StatefulWidget implements PreferredSizeWidget {
  CustomAppBar({Key? key, required this.innerBoxIsScrolled})
      : preferredSize = Size.fromHeight(kToolbarHeight + 30),
        super(key: key);
  final bool innerBoxIsScrolled;
  @override
  final Size preferredSize; // default is 56.0

  @override
  _CustomAppBarState createState() => _CustomAppBarState();
}

class _CustomAppBarState extends State<CustomAppBar> {
  late FocusNode searchFocusNode;
  @override
  void initState() {
    searchFocusNode = FocusNode();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      automaticallyImplyLeading: false,
      shape: RoundedRectangleBorder(
          side: BorderSide(),
          borderRadius: ellipticalBorder),
      snap: true,
      floating: true,
      collapsedHeight: 35,
      toolbarHeight: 35,
      expandedHeight: kToolbarHeight,
      shadowColor: onyx,
      elevation: 8,
      backgroundColor: onyx,
      systemOverlayStyle: SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          systemNavigationBarColor: Colors.transparent,
          statusBarBrightness: Brightness.dark),
      leading: null,
      title: Row(
        children: [
          IconButton(
            splashRadius: 18,
            icon: Icon(
              Icons.search,
              size: 28,
              color: Colors.white,
            ),
            onPressed: () {
              searchFocusNode.requestFocus();
            },
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: Container(
                child: TextFormField(
                  initialValue: 'Search on Rvver',
                  decoration: InputDecoration.collapsed(
                      hintText: 'Search on Rvver', hintStyle: gothicMedium),
                  focusNode: searchFocusNode,
                  style: TextStyle(
                      fontFamily: 'Gothic',
                      fontSize: 22,
                      color: Colors.white38),
                ),
              ),
            ),
          ),
          IconButton(
            splashRadius: 18,
            onPressed: () {
              Navigator.pushNamed(context, 'categories');
            },
            icon: Icon(
              Icons.redeem_outlined,
              size: 28,
            ),
          ),
          IconButton(
            splashRadius: 18,
            onPressed: () {},
            icon: Icon(Icons.notifications_outlined),
            iconSize: 28,
          ),
        ],
      ),
      bottom: PreferredSize(
        preferredSize: Size.fromHeight(80),
        child: Column(
          children: [
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  TextButton(
                    onPressed: () {},
                    child: Text('Women',
                        maxLines: 1, style: Theme.of(context).textTheme.bodyText1),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: Text('Men',
                        maxLines: 1, style: Theme.of(context).textTheme.bodyText1),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: Text('Kids',
                        maxLines: 1, style: Theme.of(context).textTheme.bodyText1),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: Text('Beauty',
                        maxLines: 1, style: Theme.of(context).textTheme.bodyText1),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: Text(
                      'Lifestyle',
                      style: Theme.of(context).textTheme.bodyText1,
                      maxLines: 1,
                    ),
                  ),
                ],
              ),
            ),
            SubCategorySlider()
          ],
        ),
      ),
      forceElevated: this.widget.innerBoxIsScrolled,
    );
  }
}
