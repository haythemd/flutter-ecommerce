import 'package:flutter/material.dart';
import 'package:rivver/style/fonts.dart';
import 'package:rivver/style/themes.dart';


AppBar mainAppBar(context) {
  final FocusNode searchFocusNode= FocusNode();
  return AppBar(
  backgroundColor:onyx,
  title: Row(
    children: [
      IconButton(
        splashRadius: 18,
        icon: Icon(
          Icons.search,
          size: 28,
          color: Colors.white,
        ),
        onPressed: () {
          searchFocusNode.requestFocus();
        },
      ),
      Expanded(
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Container(
            child: TextFormField(
              initialValue: 'Search on Rvver',
              decoration: InputDecoration.collapsed(
                  hintText: 'Search on Rvver', hintStyle: gothicMedium),
              focusNode: searchFocusNode,
              style: TextStyle(
                  fontFamily: 'Gothic',
                  fontSize: 22,
                  color: Colors.white38),
            ),
          ),
        ),
      ),
      IconButton(
        splashRadius: 18,
        onPressed: () {
          Navigator.pushNamed(context, 'categories');
        },
        icon: Icon(
          Icons.redeem_outlined,
          size: 28,
        ),
      ),
      IconButton(
        splashRadius: 18,
        onPressed: () {},
        icon: Icon(Icons.notifications_outlined),
        iconSize: 28,
      ),
    ],
  ),
  leading: null,
  centerTitle: true,
);}