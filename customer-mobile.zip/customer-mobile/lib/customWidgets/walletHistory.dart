import 'package:flutter/material.dart';
import 'package:rivver/style/fonts.dart';

class WalletHistory extends StatefulWidget {
  const WalletHistory({Key? key}) : super(key: key);

  @override
  _WalletHistoryState createState() => _WalletHistoryState();
}

class _WalletHistoryState extends State<WalletHistory> {
  @override
  Widget build(BuildContext context) {
    return Container(padding: EdgeInsets.symmetric(horizontal: 20,vertical: 5),child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [

Flexible(flex: 4,
  child:   Column(
    children: [
      Text('10/12/2015',style: nexaBlack,),
      Text('Refund',style: nexaBlack,),
      Text('expiry 10/02/2016',style: nexaBlack,),
    ],
  ),
),
      Flexible(
          child: Text('1.3 EGP',style: nexaBlack,)),

      Flexible(
          child: Text('1.3 EGP',style: nexaBlack,)),
    ],),);
  }
}
