import 'package:flutter/material.dart';

class Product {
  final int id;
  final String title, description;
  final String brand;
  final List<String> images;
  final Map<int,String> colors;
  final double rating, price;
  final bool isFavourite, isPopular;

  Product({
    required this.id,
    required this.images,
    required this.colors,
    required this.brand,
    this.rating = 0.0,
    this.isFavourite = false,
    this.isPopular = false,
    required this.title,
    required this.price,
    required this.description,
  });
}



List<Product> demoProducts = [
  Product(
    brand: 'Nike',
    id: 1,
    images: [
      "assets/images/tshirt.png",
      "assets/images/tshirt.png",
      "assets/images/tshirt.png",
      "assets/images/tshirt.png",
    ],
    colors: {
      0xFFF6625E:'red',
      0xFF836DB8:'Violet',
      0xFFDECB9C:'Yellow',
      0xFFFFFFFF:'White',
    },
    title: "Adidas Black T-Shirt",
    price: 64.99,
    description: description,
    rating: 4.8,
    isFavourite: true,
    isPopular: true,
  ),
  Product(
    id: 2,
    images: [
      "assets/images/tshirt.png",
    ],
    colors: {
      0xFFF6625E:'red',
      0xFF836DB8:'Violet',
      0xFFDECB9C:'Yellow',
      0xFFFFFFFF:'White',
    },
    title: "Nike Sport White Pant",
    price: 50.5,
    description: description,
    rating: 4.1,
    isPopular: true, brand: 'Adidas',
  ),
  Product(
    brand: 'Adidas',
    id: 3,
    images: [
      "assets/images/tshirt.png",
    ],
    colors: {
      0xFFF6625E:'red',
      0xFF836DB8:'Violet',
      0xFFDECB9C:'Yellow',
      0xFFFFFFFF:'White',
    },
    title: "Gloves ",
    price: 36.55,
    description: description,
    rating: 4.1,
    isFavourite: true,
    isPopular: true,
  ),
  Product(
    brand: 'Nike',
    id: 4,
    images: [
      "assets/images/tshirt.png",
    ],
    colors: {
      0xFFF6625E:'red',
      0xFF836DB8:'Violet',
      0xFFDECB9C:'Yellow',
      0xFFFFFFFF:'White',
    },
    title: "Example here",
    price: 20.20,
    description: description,
    rating: 4.1,
    isFavourite: true,
  ),
];

const String description =
    "This is Just a Product Description and other stuff too..";