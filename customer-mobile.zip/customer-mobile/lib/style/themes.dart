import 'package:flutter/material.dart';
import 'colors.dart';
import 'fonts.dart';

Color onyx = Color(0xff0f0f0f);

Color cyan = Color.fromARGB(255, 43, 164, 198);

Color violet = Color.fromARGB(255, 90, 39, 124);


ThemeData mainTheme = ThemeData(
  textTheme: TextTheme(
      headline1: vladivostokBig,
      bodyText1: TextStyle(fontFamily: 'SegoeUI',fontSize: 18, color: Colors.white),
      bodyText2: gothicMedium),
  bottomNavigationBarTheme: BottomNavigationBarThemeData(backgroundColor: onyx,selectedLabelStyle: TextStyle(fontFamily: 'SegoeUI', fontSize: 10, color: Colors.white),unselectedLabelStyle: TextStyle(fontFamily: 'SegoeUI', fontSize: 10, color: Colors.white))
);



const TextStyle headerTypeOne = TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: Colors.black);
const TextStyle headerTypeOneFade = TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: Colors.black54);
const TextStyle normalTypeOne = TextStyle(fontWeight: FontWeight.w500, fontSize: 14, color: Colors.black);
const TextStyle subTitleTypeOne = TextStyle(fontWeight: FontWeight.w400, fontSize: 12, color: Colors.black);
const TextStyle subTitleTypeTwo = TextStyle(fontSize: 13, fontWeight: FontWeight.w400, color: Colors.black);
const TextStyle subTitleTypeTwoFade = TextStyle(fontSize: 13, fontWeight: FontWeight.w400, color: Colors.black54);

const TextStyle headerTypeOneDark = TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: Colors.white);
const TextStyle headerTypeOneFadeDark = TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: Colors.white54);
const TextStyle normalTypeOneDark = TextStyle(fontWeight: FontWeight.w500, fontSize: 14, color: Colors.white);
const TextStyle subTitleTypeOneDark = TextStyle(fontWeight: FontWeight.w400, fontSize: 12, color: Colors.white);
const TextStyle subTitleTypeTwoDark = TextStyle(fontSize: 13, fontWeight: FontWeight.w400, color: Colors.white);
const TextStyle subTitleTypeTwoFadeDark = TextStyle(fontSize: 13, fontWeight: FontWeight.w400, color: Colors.white54);

TextTheme textTheme(BuildContext context) {
  return Theme.of(context).textTheme;
}





ThemeData dark = ThemeData.dark().copyWith(
  colorScheme: const ColorScheme.dark(
      brightness: Brightness.dark,
      primary: primaryColorDark,
      secondary: secondaryColorDark,
      background: backGroundDark,
      secondaryVariant: disableColorDark,
      onBackground: upisetDark,
      onPrimary: white),
  textTheme: const TextTheme(
    headline1: headerTypeOneDark,
    headline2: headerTypeOneFadeDark,
    bodyText1: normalTypeOneDark,
    subtitle1: subTitleTypeOneDark,
    subtitle2: subTitleTypeTwoDark,
    caption: subTitleTypeTwoFadeDark,
  ),
  backgroundColor: backGroundDark,
  scaffoldBackgroundColor: backGroundDark,
  inputDecorationTheme: const InputDecorationTheme(border: InputBorder.none),
  iconTheme: const IconThemeData(color: primaryColor),
  textButtonTheme: TextButtonThemeData(
    style: ButtonStyle(
      overlayColor: MaterialStateProperty.all(secondaryColor),
      elevation: MaterialStateProperty.all(0),
    ),
  ),
);

ThemeData light = ThemeData.light().copyWith(
  colorScheme: const ColorScheme.light(
      brightness: Brightness.light,
      primary: primaryColor,
      secondary: secondaryColor,
      background: backGround,
      secondaryVariant: disableColor,
      onBackground: upisetLight,
      onPrimary: black),
  textTheme: const TextTheme(
    headline1: headerTypeOne,
    headline2: headerTypeOneFade,
    bodyText1: normalTypeOne,
    subtitle1: subTitleTypeOne,
    subtitle2: subTitleTypeTwo,
    caption: subTitleTypeTwoFade,
  ),
  inputDecorationTheme: const InputDecorationTheme(border: InputBorder.none),
  scaffoldBackgroundColor: backGround,
  iconTheme: const IconThemeData(color: primaryColor),
  textButtonTheme: TextButtonThemeData(
    style: ButtonStyle(
      overlayColor: MaterialStateProperty.all(secondaryColor),
      elevation: MaterialStateProperty.all(0),
    ),
  ),
);

// void setSystemColoring() {
//   //! I Know This is Nasty i Will fix it in Future
//   if (Platform.isAndroid) {
//     SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
//       statusBarIconBrightness: Get.isDarkMode == true ? Brightness.light : Brightness.dark,
//       systemNavigationBarColor: Get.isDarkMode == true ? disableColorDark : backGround,
//       systemNavigationBarIconBrightness: Get.isDarkMode == true ? Brightness.light : Brightness.dark,
//       statusBarColor: Colors.transparent,
//     ));
//   } else if (Platform.isIOS) {
//     SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
//       statusBarBrightness: Get.isDarkMode == true ? Brightness.dark : Brightness.light,
//     ));
//   }
// }

currentTheme() {}




