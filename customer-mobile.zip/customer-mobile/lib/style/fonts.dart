import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:rivver/style/themes.dart';


//Vladivostok
TextStyle vladivostokBig = TextStyle(
    shadows: [Shadow(color: Color.fromARGB(255, 43, 164, 198), blurRadius: 0)],
    fontFamily: 'Vladivostok',
    fontWeight: FontWeight.w700,
    fontSize: 42,
    color: Color.fromARGB(255, 43, 164, 198));


//Gothic
TextStyle gothicMedium =
TextStyle(fontFamily: 'Gothic', fontSize: 22, color: Colors.white);

TextStyle gothicBlackSmall =
TextStyle(fontFamily: 'Gothic', fontSize: 18, color: Colors.black);


//Segoe
TextStyle segoeMedium =
TextStyle(fontFamily: 'SegoeUI', fontSize: 18, color: Colors.white);

TextStyle segoeBoldBig =
TextStyle(fontFamily: 'SegoeUI', fontSize: 36,color:Colors.black54);

TextStyle segoeBlackSmall =
TextStyle(fontFamily: 'SegoeUI', fontSize: 12, color: Colors.black);


TextStyle segoeBlack18 =
TextStyle(fontFamily: 'SegoeUI', fontSize: 18, color: Colors.black);


TextStyle segoeGreySmall =
TextStyle(fontFamily: 'SegoeUI', fontSize: 18, color: Colors.grey);

TextStyle segoeGreySmallLine =
TextStyle(fontFamily: 'SegoeUI', fontSize: 12, color: Colors.grey,decoration: TextDecoration.lineThrough);


TextStyle segoeRedSmall =
TextStyle(fontFamily: 'SegoeUI', fontSize: 18, color: Colors.red);


TextStyle segoeBlackBold =
TextStyle(fontFamily: 'SegoeUI', fontSize: 34,color:Colors.black);


TextStyle gothicWhiteBig =
TextStyle(fontFamily: 'Gothic', fontSize: 32, color: Colors.black);


TextStyle gothicBlack24 =
TextStyle(fontFamily: 'Gothic', fontSize: 24, color: Colors.black,fontWeight: FontWeight.w700);

TextStyle segoeWhiteBig = TextStyle(fontFamily: 'SegoeUI',
  fontWeight: FontWeight.w700,fontSize: 36,color: Colors.white);

TextStyle segoeSmallGreen = TextStyle(fontFamily: 'SegoeUI',
    fontSize: 16,color: Colors.green);

TextStyle segoeWhiteSmall = TextStyle(fontFamily: 'SegoeUI',
    fontSize: 14,color: Colors.white);

TextStyle loraBlackSmall = GoogleFonts.sarabun(fontSize:10,color: onyx);
TextStyle gothicGreySmall =
TextStyle(fontFamily: 'Gothic', fontSize: 12, color: Colors.grey);



TextStyle segoeBlackBig = TextStyle(fontFamily: 'SegoeUI',
    fontWeight: FontWeight.w700,fontSize: 16,color: Colors.black);













TextStyle nexaBoldBlack = TextStyle(fontFamily: 'Nexa',color: onyx,fontSize: 24,fontWeight: FontWeight.w600);
TextStyle nexaTextBlack = TextStyle(fontFamily: 'SegoeUI',color: onyx,fontSize: 16,);

TextStyle nexaBlack = TextStyle(fontFamily: 'Nexa',color: Color(0xFF333333),fontSize: 16,);
