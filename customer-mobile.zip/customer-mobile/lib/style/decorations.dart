import 'package:flutter/material.dart';

import 'colors.dart';

const BoxDecoration searchWidgetDecoration = BoxDecoration(
  borderRadius: BorderRadius.all(Radius.circular(10)),
);
const BoxDecoration followButtonDecoration = BoxDecoration(
  color: primaryColor,
  borderRadius: BorderRadius.all(Radius.circular(8)),
);
const BoxDecoration followingButtonDecoration = BoxDecoration(
  color: disableColor,
  borderRadius: BorderRadius.all(Radius.circular(10)),
);
BoxDecoration postDescriptionDecoration = BoxDecoration(
  border: Border.all(color: Colors.black26),
  borderRadius: const BorderRadius.all(Radius.circular(25)),
);
