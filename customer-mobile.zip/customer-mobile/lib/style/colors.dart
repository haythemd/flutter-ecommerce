import 'package:flutter/material.dart';

const Color primaryColor = Color(0xFF54beb7);
const Color secondaryColor = Color(0xFF14615a);
const Color disableColor = Color(0xFFFFFFFF);
const Color backGround = Color(0xFFF5F3F3);
const Color upisetLight = Colors.black26;
const Color black = Colors.black87;

const Color primaryColorDark = Color(0xFFa2e4de);
const Color secondaryColorDark = Color(0xFF4debc5);
const Color backGroundDark = Color(0xFF1c1c1c);
const Color disableColorDark = Color(0xFF262626);
const Color upisetDark = Colors.white24;
const Color white = Colors.white70;
ColorScheme colorScheme(BuildContext context) {
  return Theme.of(context).colorScheme;
}
