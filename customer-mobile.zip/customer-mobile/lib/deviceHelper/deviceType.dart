import 'package:flutter/foundation.dart';



bool isMobile() {
bool? type;
if ((defaultTargetPlatform == TargetPlatform.iOS) || (defaultTargetPlatform == TargetPlatform.android)) {
// Some android/ios specific code
type = true;
} else if ((defaultTargetPlatform == TargetPlatform.linux) ||
(defaultTargetPlatform == TargetPlatform.macOS) ||
(defaultTargetPlatform == TargetPlatform.windows)) {
// Some desktop specific code there
type = false;
} else {
// Some web specific code there
type = false;
}
return type;
}

