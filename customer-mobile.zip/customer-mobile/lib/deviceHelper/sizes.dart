import 'package:flutter/material.dart';

double deviceHeight(context) {
  return MediaQuery.of(context).size.height;
}

double deviceWidth(context) {
  return MediaQuery.of(context).size.width;
}

double topSafeAreSize(context) {
  return MediaQuery.of(context).padding.top;
}

double bottomSafeAreSize(context) {
  return MediaQuery.of(context).padding.top;
}

Orientation deviceOrientation(context) {
  return MediaQuery.of(context).orientation;
}

bool isSmall(context) {
  bool small = false;
  if (deviceHeight(context) < 720) {
    small = true;
  } else {
    small = false;
  }
  return small;
}
