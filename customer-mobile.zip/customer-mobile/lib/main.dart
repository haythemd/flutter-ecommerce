import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:rivver/style/themes.dart';
import 'constants.dart';

void main() {
  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      systemNavigationBarDividerColor: Colors.transparent));

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);



  @override
  Widget build(BuildContext context) {

    return MaterialApp(
        theme: mainTheme,
        debugShowCheckedModeBanner: false,
        initialRoute: 'splash',
        routes: routes);
  }
}

